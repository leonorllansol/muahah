import os
CURRENT_DIR = os.path.dirname(os.path.abspath(__file__))
os.chdir(CURRENT_DIR)
import agents.talkpedia
import agents.talkpedia.talkpedia
